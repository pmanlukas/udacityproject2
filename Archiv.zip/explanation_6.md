## On my implementation

In this problem, first I have created a set for making union & intersection of the two linked list. Then I have created a new linked list from the set.



## On my runtime

For Union as well as for the Intersection we have to got at least through all the elements, since we add every one to a set and then add all from the set to a list again. Therefore our runtime is always linear.

Union: 
- Time complexity: O(n) 
- Space complexity: O(n)


Intersection: 
- Time complexity: O(n) 
- Space complexity: O(n)

